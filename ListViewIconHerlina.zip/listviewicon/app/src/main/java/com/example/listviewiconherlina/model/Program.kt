package com.example.listviewiconherlina.model

class Program {
        var nama: String = ""
        var deskripsi: String = ""
        var gambar: Int = 0
}